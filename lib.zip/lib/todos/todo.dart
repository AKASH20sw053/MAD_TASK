class ToDo {
  String title;
  bool isDone;

  ToDo({required this.title, required this.isDone});
   
  
}
