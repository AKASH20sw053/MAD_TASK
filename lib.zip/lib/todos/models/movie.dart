class Movie {
  final String title;
  final String? runtime;

  Movie({required this.title, this.runtime});
}
